#include<stdio.h>
#include<string.h>
void main()
{
	int total,rent,p,room,days,mc,ac,fb=0,amib=0,bfb=0,lb=0,db=0,fc,bc,lc,dc,cost,t;
	char name[40],n1[20];
	printf("\nWelcome to ORION");
	printf("\nHave A Pleasant Stay ");
	printf("\nName: ");
	gets(name);
	printf("\nTotal People: ");
	scanf("%d",&p);  //pax=p
	printf("\nThe charge of rooms are fixed as stay per day.");
	printf("\n\nROOM TYPES\t\tROOM RATE PER DAY");
	printf("\n1.Standard\t\t1400");
	printf("\n2.Delux\t\t\t2200");
	printf("\n3.Super Delux\t\t4000");
	printf("\n4.Suits\t\t\t7500");
	printf("\n\nFor how long is your stay plan for? ");
	scanf("%d",&days);
	room_selection:
	printf("\nIn which type of room you want to make your self comfortable: ");
	scanf("%d",&room);   //m=room
	if(room==1)
	{
		rent=1400;
		strcpy(n1,"Standard");
	}
	else if(room==2)
	{
		rent=2200;
		strcpy(n1,"Delux");
	}
	else if(room==3)
	{
		rent=4000;
		strcpy(n1,"Super Delux");
	}
	else if(room==4)
	{
		rent=7500;
		strcpy(n1,"Suits");
	}
	else
	{
		printf("\nINVALID INPUT\n");
		sleep(2);
		goto room_selection;
	}
	total=days*rent;
	while(mc!=3)
	{
		system("cls");
		printf("\nWelcome to ORION");
		printf("\nHave A Pleasant Stay ");
		printf("\n\nName : %s\t\tNo of People : %d",name,p);
		printf("\nRoom Type : %s\t\tDays : %d",n1,days);
		printf("\n============================================================================");//+12 =
		printf("\nRoom Bill : %d\tFood Bill : %d\t\tAmenities Bill : %d",total,fb,amib); 
		printf("\nBreakfast : %d\t\tLunch : %d\t\tDinner : %d",bfb,lb,db); 
		printf("\n============================================================================");
		printf("\n\nMain menu"); // \n to leave 1 line
		printf("\n1.Food");
		printf("\n2.Amenities");
		printf("\n3.Final Bill");
		printf("\n\nPlease choose your choice: ");
		scanf("%d",&mc);
		fc=0;
		ac=0;
		switch(mc)
		{
			case 1:
			{
			while (fc!=4)
			{
				system("cls");
				printf("\nWelcome to ORION");
				printf("\nHave A Pleasant Stay ");
				printf("\n\nName : %s\t\tNo of People : %d",name,p);
				printf("\nRoom Type : %s\t\tDays : %d",n1,days);
				printf("\n============================================================================");//+12 =
				printf("\nRoom Bill : %d\tFood Bill : %d\t\tAmenities Bill : %d",total,fb,amib); 
				printf("\nBreakfast : %d\t\tLunch : %d\t\tDinner : %d",bfb,lb,db); 
				printf("\n============================================================================");
				printf("\n\n1.Breakfast");
				printf("\n2.Lunch");
				printf("\n3.Dinner");
				printf("\n4.Exit to Main Menu");
				printf("\n\nPlease choose your choice: ");
				scanf("%d",&fc);
				bc=0; // overwrite value of bc to again go for breakfast
				lc=0;
				dc=0;
				switch(fc)
				{
					case 1:
					while(bc!=6)
					{
						system("cls");
						printf("\nWelcome to ORION");
						printf("\nHave A Pleasant Stay ");
						printf("\n\nName : %s\t\tNo of People : %d",name,p);
						printf("\nRoom Type : %s\t\tDays : %d",n1,days);
						printf("\n============================================================================");//+12 =
						printf("\nRoom Bill : %d\tFood Bill : %d\t\tAmenities Bill : %d",total,fb,amib); 
						printf("\nBreakfast : %d\t\tLunch : %d\t\tDinner : %d",bfb,lb,db); 
						printf("\n============================================================================");
						printf("\n\nWelcome (Breakfast Menu)");
						printf("\n\nFood Items\t\tPrice");
						printf("\n1.Baked Beans\t\t350");
						printf("\n2.Italian salad\t\t375");
						printf("\n3.Doughnuts\t\t300");
						printf("\n4.Sandwich\t\t200");
						printf("\n5.Omlette\t\t225");
						printf("\n6.Exit to Food Menu");
						printf("\n\nWhat would you like to have? ");
						scanf("%d",&bc);
						switch(bc)
						{
							case 1:
							cost=350;
							printf("How many plates would you like to order? ");
							scanf("%d",&t);
							cost=t*cost;
							bfb=bfb+cost;
							fb=fb+cost;
							printf("Your total cost is %d",cost);
							sleep(2);
							break;
							
							case 2: 
							cost=375;
							printf("How many plates would you like to order? ");
							scanf("%d",&t);
							cost=t*cost;
							bfb=bfb+cost;
							fb=fb+cost;
							printf("Your total cost is %d",cost);
							sleep(2);
							break;
							
							case 3:
							cost=300;
							printf("How many plates would you like to order? ");
							scanf("%d",&t);
							cost=t*cost;
							bfb=bfb+cost;
							fb=fb+cost;
							printf("Your total cost is %d",cost);
							sleep(2);
							break;
							
							case 4:
							cost=200;
							printf("How many plates would you like to order? ");
							scanf("%d",&t);
							cost=t*cost;
							bfb=bfb+cost;
							fb=fb+cost;
							printf("Your total cost is %d",cost);
							sleep(2);
							break;
							
							case 5:
							cost=225;
							printf("How many plates would you like to order? ");
							scanf("%d",&t);
							cost=t*cost;
							bfb=bfb+cost;
							fb=fb+cost;
							printf("Your total cost is %d",cost);
							sleep(2);
							break;
							
							case 6:
							break;
							
							default:
							printf("\nSorry, not available");
							sleep(2);
						}
					}
					break;
					
					case 2:
					while (lc!=9)
					{
						system("cls");
						printf("\nWelcome to ORION");
						printf("\nHave A Pleasant Stay ");
						printf("\n\nName : %s\t\tNo of People : %d",name,p);
						printf("\nRoom Type : %s\t\tDays : %d",n1,days);
						printf("\n============================================================================");//+12 =
						printf("\nRoom Bill : %d\tFood Bill : %d\t\tAmenities Bill : %d",total,fb,amib); 
						printf("\nBreakfast : %d\t\tLunch : %d\t\tDinner : %d",bfb,lb,db); 
						printf("\n============================================================================");
						printf("\n\nWelcome (Lunch Menu)");
						printf("\n\nFood Items\t\tPrice");
						printf("\n1.Pasta\t\t\t450");
						printf("\n2.Mexican Rice\t\t570");
						printf("\n3.Japanese Sushi\t850");
						printf("\n4.Atlantic Salmon\t800");
						printf("\n5.Baked Vegetable\t400");
						printf("\n6.Sizzler\t\t1050");
						printf("\n7.Beef Wellington\t1400");
						printf("\n8.Eggs benedict\t\t1600");
						printf("\n9.Exit to Food Menu");
						printf("\n\nWhat would you like to have?");
						scanf("%d",&lc);
						switch(lc)
						{
							case 1:
							cost=450;
							printf("How many plates would you like to order? ");
							scanf("%d",&t);
							cost=t*cost;
							lb=lb+cost;
							fb=fb+cost;
							printf("Your total cost is %d",cost);
							sleep(2);
							break;
							
							case 2: 
							cost=570;
							printf("How many plates would you like to order? ");
							scanf("%d",&t);
							cost=t*cost;
							lb=lb+cost;
							fb=fb+cost;
							printf("Your total cost is %d",cost);
							sleep(2);
							break;
							
							case 3:
							cost=850;
							printf("How many plates would you like to order? ");
							scanf("%d",&t);
							cost=t*cost;
							lb=lb+cost;
							fb=fb+cost;
							printf("Your total cost is %d",cost);
							sleep(2);
							break;
							
							case 4:
							cost=800;
							printf("How many plates would you like to order? ");
							scanf("%d",&t);
							cost=t*cost;
							lb=lb+cost;
							fb=fb+cost;
							printf("Your total cost is %d",cost);
							sleep(2);
							break;
							
							case 5:
							cost=400;
							printf("How many plates would you like to order? ");
							scanf("%d",&t);
							cost=t*cost;
							lb=lb+cost;
							fb=fb+cost;
							printf("Your total cost is %d",cost);
							sleep(2);
							break;
							
							case 6:
							cost=1050;
							printf("How many plates would you like to order? ");
							scanf("%d",&t);
							cost=t*cost;
							lb=lb+cost;
							fb=fb+cost;
							printf("Your total cost is %d",cost);
							sleep(2);
							break;
							
							case 7:
							cost=1400;
							printf("How many plates would you like to order? ");
							scanf("%d",&t);
							cost=t*cost;
							lb=lb+cost;
							fb=fb+cost;
							printf("Your total cost is %d",cost);
							sleep(2);
							break;
							
							case 8:
							cost=1600;
							printf("How many plates would you like to order? ");
							scanf("%d",&t);
							cost=t*cost;
							lb=lb+cost;
							fb=fb+cost;
							printf("Your total cost is %d",cost);
							sleep(2);
							break;
							
							case 9:
							break;
							
							default:
							printf("\nSorry, not available");
							sleep(2);
						}
					}
					break;
					
					case 3:
					while (dc!=11)
					{
						system("cls");
						printf("\nWelcome to ORION");
						printf("\nHave A Pleasant Stay ");
						printf("\n\nName : %s\t\tNo of People : %d",name,p);
						printf("\nRoom Type : %s\t\tDays : %d",n1,days);
						printf("\n============================================================================");//+12 =
						printf("\nRoom Bill : %d\tFood Bill : %d\t\tAmenities Bill : %d",total,fb,amib); 
						printf("\nBreakfast : %d\t\tLunch : %d\t\tDinner : %d",bfb,lb,db); 
						printf("\n============================================================================");
						printf("\n\nWelcome (Dinner Menu)");
						printf("\n\nFood Items\t\tPrice");
						printf("\n1.Enchiladas\t\t800");
						printf("\n2.Lasagne\t\t1150");
						printf("\n3.Ravioli\t\t1350");
						printf("\n4.Mexican Hot Pot\t750");
						printf("\n5.Tacos\t\t\t350");
						printf("\n6.Ratatoullie\t\t1700");
						printf("\n7.Paella\t\t1200");
						printf("\n8.Massaman Curry\t2000");
						printf("\n9.Jelo\t\t\t800");
						printf("\n10.Chocolate Souffle\t900");
						printf("\n11.Exit to Food Menu");
						printf("\n\nWhat would you like to have?");
						scanf("%d",&dc);
						switch(dc)
						{
							case 1:
							cost=800;
							printf("How many plates would you like to order? ");
							scanf("%d",&t);
							cost=t*cost;
							db=db+cost;
							fb=fb+cost;
							printf("Your total cost is %d",cost);
							sleep(2);
							break;
							
							case 2: 
							cost=1150;
							printf("How many plates would you like to order? ");
							scanf("%d",&t);
							cost=t*cost;
							db=db+cost;
							fb=fb+cost;
							printf("Your total cost is %d",cost);
							sleep(2);
							break;
							
							case 3:
							cost=1350;
							printf("How many plates would you like to order? ");
							scanf("%d",&t);
							cost=t*cost;
							db=db+cost;
							fb=fb+cost;
							printf("Your total cost is %d",cost);
							sleep(2);
							break;
					
							case 4:
							cost=750;
							printf("How many plates would you like to order? ");
							scanf("%d",&t);
							cost=t*cost;
							db=db+cost;
							fb=fb+cost;
							printf("Your total cost is %d",cost);
							sleep(2);
							break;
							
							case 5:
							cost=350;
							printf("How many plates would you like to order? ");
							scanf("%d",&t);
							cost=t*cost;
							db=db+cost;
							fb=fb+cost;
							printf("Your total cost is %d",cost);
							sleep(2);
							break;
							
							case 6:
							cost=1700;
							printf("How many plates would you like to order? ");
							scanf("%d",&t);
							cost=t*cost;
							db=db+cost;
							fb=fb+cost;
							printf("Your total cost is %d",cost);
							sleep(2);
							break;
							
							case 7:
							cost=1200;
							printf("How many plates would you like to order? ");
							scanf("%d",&t);
							cost=t*cost;
							db=db+cost;
							fb=fb+cost;
							printf("Your total cost is %d",cost);
							sleep(2);
							break;
							
							case 8:
							cost=2000;
							printf("How many plates would you like to order? ");
							scanf("%d",&t);
							cost=t*cost;
							db=db+cost;
							fb=fb+cost;
							printf("Your total cost is %d",cost);
							sleep(2);
							break;
							
							case 9:
							cost=800;
							printf("How many plates would you like to order? ");
							scanf("%d",&t);
							cost=t*cost;
							db=db+cost;
							fb=fb+cost;
							printf("Your total cost is %d",cost);
							sleep(2);
							break;
							
							case 10:
							cost=900;
							printf("How many plates would you like to order? ");
							scanf("%d",&t);
							cost=t*cost;
							db=db+cost;
							fb=fb+cost;
							printf("Your total cost is %d",cost);
							sleep(2);
							break;
							
							case 11:
							break;
							
							default:
							printf("\nSorry, not available");
							sleep(2);
						}
					}
				}
			}
			}
			break;
			
			case 2:
			{
			while (ac!=5) //changed 4 to 5
			{
				system("cls");
				printf("\nWelcome to ORION");
				printf("\nHave A Pleasant Stay ");
				printf("\n\nName : %s\t\tNo of People : %d",name,p);
				printf("\nRoom Type : %s\t\tDays : %d",n1,days);
				printf("\n============================================================================");//+12 =
				printf("\nRoom Bill : %d\tFood Bill : %d\t\tAmenities Bill : %d",total,fb,amib); 
				printf("\nBreakfast : %d\t\tLunch : %d\t\tDinner : %d",bfb,lb,db); 
				printf("\n============================================================================");
				printf("\n\nWelcome (Amenities Menu)");
				printf("\n\nAmenities\t\tPrice per hour");
				printf("\n1.Gym\t\t\t200");
				printf("\n2.Indoor Games:\t\t250");
				printf("\n  (Table Tennis/\n  Foozball/\n  Pool Table)");
				printf("\n3.Outdoor Games:\t450");
				printf("\n  (Lawn Tennis/\n  Badminton/\n  Mini golf)");
				printf("\n4.Spa\t\t\t4500");
				printf("\n5.Exit to Main Menu");
				printf("\n\nPlease enter your choice");
				scanf("%d",&ac);
				switch(ac)
				{
					case 1:
					cost=200;
					amib=amib+cost;
					printf("Your total cost is %d",cost);
					sleep(2);
					break;
					
					case 2:
					cost=250;
					amib=amib+cost;
					printf("Your total cost is %d",cost);
					sleep(2);
					break;
					
					case 3:
					cost=450;
					amib=amib+cost;
					printf("Your total cost is %d",cost);
					sleep(2);
					break;
					
					case 4:
					cost=4500;
					amib=amib+cost;
					printf("Your total cost is %d",cost);
					sleep(2);
					break;
					
					case 5:
					break;
					
					default:
					printf("\nSorry, not available");
					sleep(2);
				}
			}
			}
			break;
			
			case 3:
			{
				system("cls");
				printf("\n============================================================================");//+12 =
				printf("\nORION"); 
				printf("\n============================================================================");
				printf("\n\nName : %s\t\t\tNo of People : %d",name,p);
				printf("\nRoom Type : %s\t\t\tDays : %d",n1,days);
				printf("\n============================================================================");
				printf("\nNo\tDescription\t\tRate\t\tQuantity\tAmount");
				printf("\n============================================================================");
				printf("\n1.\t%s \t\t%d \t\t%d \t\t%d",n1,rent,days,total);
				printf("\n2.\tFood Bill \t\t\t\t\t\t%d",fb);
				printf("\n\tBreakfast Bill \t\t\%d",bfb);
				printf("\n\tLunch Bill \t\t\%d",lb);
				printf("\n\tDinner Bill \t\t\%d",db);
				printf("\n3.\tAminities Bill \t\t\t\t\t\t%d",amib);
				printf("\n----------------------------------------------------------------------------");
				printf("\n\tTotal Bill\t\t\t\t\t\t%d",total+fb+amib);
				double tax=(double) (total+fb+amib)*0.05;
				printf("\n\tTaxes \t\t\t\t\t\t\t%lf",tax);
				printf("\n----------------------------------------------------------------------------");
				printf("\n\tGrand Total (Total Bill + Taxes) \t\t\t%lf",total+fb+amib+tax);
				printf("\n");
				printf("\n\t\t\t\t\t For ORION");
				printf("\n\t\t\t\t\tFor Seal & Sign");
				printf("\nTearms & Condition");
				printf("\n1.xxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
				printf("\n2.yyyyyyyyyyyyyyyyyyyyyyyyyyyyy");
				printf("\n3.zzzzzzzzzzzzzzzzzzzzzzzzzzzzz");
				printf("\n");
				printf("\nThank You");
				printf("\nVisit Again");
				printf("\n");
				printf("\n");
				printf("\n");
				printf("\n");
				printf("\n");				
			}
		}
	}
}
