/* 
 * C Program to Implement Priority Queue to Add and Delete Elements
 */
#include <stdio.h>
#include <stdlib.h>
#define MAX 5
 
void marketing(int);
void delete_marketing(int);
void create_marketing();
void check(int);
void checkr(int);
void display_pqueue();
int marketing1[MAX];
int front_m, rear_m;
 
void store(int);
void delete_store(int);
void create_store();
void checkr(int);
int store1[MAX];
int front_r, rear_r; 
 
void sales(int);
void delete_sales(int);
void create_sales();
void checks(int);
int sales1[MAX];
int front_s, rear_s; 
 
void despatch(int);
void delete_despatch(int);
void create_despatch();
void checkd(int);
int despatch1[MAX];
int front_d, rear_d; 
 
void account(int);
void create_account();
void checka(int);
int account1[MAX];
int front_a, rear_a,i; 

 
void main()
{
    int n, ch, ch1;
    printf("\n1 - Insert an element into queue");
    printf("\n2 - Move Order or Inquiry to next Department");                                  
    printf("\n3 - Display queue elements");
    printf("\n4 - Exit");
    create_marketing();
    while (1)
    {
        printf("\nEnter your choice : ");    
        scanf("%d", &ch);
        switch (ch)
        {
        case 1: 
            printf("\nEnter value to be inserted : ");
            scanf("%d",&n);
            marketing(n);
            break;
        case 2:
            printf("\n1. Marketing Department to Store Department ");
            printf("\n2. Store Department to Sales Department ");
            printf("\n3. Sales Department to Delivery/Dispatch Department ");
            printf("\n4. Delivery/Dispatch Department to Account Department ");
            printf("\n5. Exit ");
		    do 
		    {
        		printf("\nEnter your choice1 : ");    
        		scanf("%d", &ch1);
 		        switch (ch1)
        		{
        		case 1: 
	               n=marketing1[0];
	               printf("%d",n);
    	           delete_marketing(n);
    	           store(n);
        	       break;
        		case 2: 
	               n=store1[0];
	               printf("%d",n);
    	           delete_store(n);
    	           sales(n);
        	       break;
        		case 3: 
	               n=sales1[0];
	               printf("%d",n);
    	           delete_sales(n);
    	           despatch(n);
        	       break;
        		case 4: 
	               n=despatch1[0];
	               printf("%d",n);
    	           delete_despatch(n);
    	           account(n);
        	       break;
	        	case 5: 
            		break;
	        	default: 
    	        	printf("\nChoice is incorrect, Enter a correct choice");
        	   }
        	}
        	while(ch1!=5);
			break;	
        case 3: 
            display_pqueue();
            break;
        case 4: 
            exit(0);
        default: 
            printf("\nChoice is incorrect, Enter a correct choice");
        }
    }
}
/* Function to create_marketing an empty priority queue */
void create_marketing()
{
    front_m = rear_m = -1;
}
void create_store()
{
    front_r = rear_r = -1;
}
void create_sales()
{
    front_s = rear_s = -1;
}
void create_despatch()
{
    front_d = rear_d = -1;
}
void create_account()
{
    front_a = rear_a = -1;
}
/* Function to insert value into priority queue */
void marketing(int data)
{
    if (rear_m >= MAX - 1)
    {
        printf("\nQueue overflow no more elements can be inserted");
        return;
    }
    if ((front_m == -1) && (rear_m == -1))
    {
        front_m++;
        rear_m++;
        marketing1[rear_m] = data;
        return;
    }    
    else
        check(data);
    rear_m++;
}
void store(int data1)
{
    if (rear_r >= MAX - 1)
    {
        printf("\nQueue overflow no more elements can be inserted");
        return;
    }
    if ((front_r == -1) && (rear_r == -1))
    {
        front_r++;
        rear_r++;
        
        store1[rear_r] =data1;
        return;
    }    
    else
        checkr(data1);
    rear_r++;
}
void sales(int data2)
{
    if (rear_s >= MAX - 1)
    {
        printf("\nQueue overflow no more elements can be inserted");
        return;
    }
    if ((front_s == -1) && (rear_s == -1))
    {
        front_s++;
        rear_s++;
        
        sales1[rear_s] =data2;
        return;
    }    
    else
        checks(data2);
    rear_s++;
}
void despatch(int data3)
{
    if (rear_d >= MAX - 1)
    {
        printf("\nQueue overflow no more elements can be inserted");
        return;
    }
    if ((front_d == -1) && (rear_d == -1))
    {
        front_d++;
        rear_d++;
        
        despatch1[rear_d] =data3;
        return;
    }    
    else
        checkd(data3);
    rear_d++;
}
void account(int data4)
{
    if (rear_a >= MAX - 1)
    {
        printf("\nQueue overflow no more elements can be inserted");
        return;
    }
    if ((front_a == -1) && (rear_a == -1))
    {
        front_a++;
        rear_a++;
        
        account1[rear_a] =data4;
        return;
    }    
    else
        checka(data4);
    rear_a++;
}
/* Function to check priority and place element */
void check(int data)
{
    int i,j;
 
    for (i = 0; i <= rear_m; i++)
    {
        if (data >= marketing1[i])
        {
            for (j = rear_m + 1; j > i; j--)
            {
                marketing1[j] = marketing1[j - 1];
            }
            marketing1[i] = data;
            return;
        }
    }
    marketing1[i] = data;
}
void checkr(int data1)
{
    int i,j;
 
    for (i = 0; i <= rear_r; i++)
    {
        if (data1 >= store1[i])
        {
            for (j = rear_r + 1; j > i; j--)
            {
                store1[j] = store1[j - 1];
            }
            store1[i] = data1;
            return;
        }
    }
    store1[i] = data1;
}
void checks(int data2)
{
    int i,j;
 
    for (i = 0; i <= rear_s; i++)
    {
        if (data2 >= sales1[i])
        {
            for (j = rear_s + 1; j > i; j--)
            {
                sales1[j] = sales1[j - 1];
            }
            sales1[i] = data2;
            return;
        }
    }
    sales1[i] = data2;
}
void checkd(int data3)
{
    int i,j;
 
    for (i = 0; i <= rear_d; i++)
    {
        if (data3 >= despatch1[i])
        {
            for (j = rear_d + 1; j > i; j--)
            {
                despatch1[j] = despatch1[j - 1];
            }
            despatch1[i] = data3;
            return;
        }
    }
    despatch1[i] = data3;
}
void checka(int data4)
{
    int i,j;
    for (i = 0; i <= rear_a; i++)
    {
        if (data4 >= account1[i])
        {
            for (j = rear_a + 1; j > i; j--)
            {
                account1[j] = account1[j - 1];
            }
            account1[i] = data4;
            return;
        }
    }
    account1[i] = data4;
}
/* Function to delete an element from queue */
void delete_marketing(int data)
{
    int i;
     if ((front_m==-1) && (rear_m==-1))
    {
        printf("\nQueue is empty no elements to delete");
        return;
    }
     for (i = 0; i <= rear_m; i++)
    {
        if (data == marketing1[i])
        {
            for (; i < rear_m; i++)
            {
                marketing1[i] = marketing1[i + 1];
            }
         marketing1[i] = -99;
        rear_m--;
         if (rear_m == -1) 
            front_m = -1;
        return;
        }
    }
    printf("\n%d not found in queue to delete", data);
}
void delete_store(int data1)
{
    int i;
     if ((front_r==-1) && (rear_r==-1))
    {
        printf("\nQueue is empty no elements to delete");
        return;
    }
     for (i = 0; i <= rear_r; i++)
    {
        if (data1 == store1[i])
        {
            for (; i < rear_r; i++)
            {
                store1[i] = store1[i + 1];
            }
         store1[i] = -99;
        rear_r--;
         if (rear_r == -1) 
            front_r = -1;
        return;
        }
    }
    printf("\n%d not found in queue to delete", data1);
}
void delete_sales(int data2)
{
    int i;
     if ((front_s==-1) && (rear_s==-1))
    {
        printf("\nQueue is empty no elements to delete");
        return;
    }
     for (i = 0; i <= rear_s; i++)
    {
        if (data2 == sales1[i])
        {
            for (; i < rear_s; i++)
            {
                sales1[i] = sales1[i + 1];
            }
         sales1[i] = -99;
        rear_s--;
         if (rear_s == -1) 
            front_s = -1;
        return;
        }
    }
    printf("\n%d not found in queue to delete", data2);
}
void delete_despatch(int data3)
{
    int i;
     if ((front_d==-1) && (rear_d==-1))
    {
        printf("\nQueue is empty no elements to delete");
        return;
    }
     for (i = 0; i <= rear_d; i++)
    {
        if (data3 == despatch1[i])
        {
            for (; i < rear_d; i++)
            {
                despatch1[i] = despatch1[i + 1];
            }
         despatch1[i] = -99;
        rear_d--;
         if (rear_d == -1) 
            front_d = -1;
        return;
        }
    }
    printf("\n%d not found in queue to delete", data3);
}
/* Function to display queue elements */
void display_pqueue()
{
    if ((front_m == -1) && (rear_m == -1))
    {
        printf("\nQueue is empty");
        return;
    }
    i==0;
 	printf("Marketing : "); 
    for (; front_m <= rear_m; front_m++)
    {
        printf("\t%d", marketing1[front_m]);
    }
    front_m = 0;

    if ((front_r == -1) && (rear_r == -1))
    {
        printf("\nQueue is empty");
        return;
    }	      
 	printf("\nStore     : ");
    for (; front_r <= rear_r; front_r++)
    {
        printf("\t%d", store1[front_r]);
    }
    front_r = 0;

    if ((front_s == -1) && (rear_s == -1))
    {
        printf("\nQueue is empty");
        return;
    }
    printf("\nSales     :");
    for (; front_s <= rear_s; front_s++)
    {
        printf("\t%d", sales1[front_s]);
    }
    front_s = 0;

    if ((front_d == -1) && (rear_d == -1))
    {
        printf("\nQueue is empty");
        return;
    }
 		printf("\nDespatch  :");
    for (; front_d <= rear_d; front_d++)
    {
        printf("\t%d", despatch1[front_d]);
    }
    front_d = 0;

    if ((front_a == -1) && (rear_a == -1))
    {
        printf("\nQueue is empty");
        return;
    } 
 		printf("\nAccount   :");
    for (; front_a <= rear_a; front_a++)
    {
        printf("\t%d", account1[front_a]);
    }
    front_a = 0;
}
