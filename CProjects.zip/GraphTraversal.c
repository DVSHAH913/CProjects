#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
//variables
int queue[100], front=-1, rear=-1; 							 //queue
int a[20][20], visit[100]; 									 //adjacency matrix
int stack[100], top=-1;                                      //stack
//fuctions
int add(int item);
int push(int item);
int pop();
int del();
int bfs(int s, int n);
int dfs(int s, int n);
//
int add(int item)
{
	if(rear==14)
	printf("queue full");
	else
	{
		if(rear==-1)
		{
			queue[++rear]=item;
			front++;
		}
		else
		queue[++rear]=item;
	}
}
//
int push(int item)
{
	if(top==14)
	{
		printf("Stack overflow");
	}
	else
	{
		stack[++top]=item;
	}
}
//
int pop()
{
	int k;
	if(top==-1)
	{
		return(0);
	}
	else
	{
		k=stack[top--];
		return(k);
	}
}
//
int del()
{
	int k;
	if((front>rear)||(front==-1))
	{
		return(0);
	}
	else
	{
		k=queue[front++];
		return (k);
	}
	
}
//
int bfs(int s, int n)
{
		int p,i;
		add(s);
		visit[s]=1;
		p=del();
		if(p!=0)
		printf(" %d",p);
		while(p!=0)
			{
				for(i=1;i<=n;i++)
				if((a[p][i]!=0)&&(visit[i]==0))
			{
				add(i);
				visit[i]=1;
			}
				p=del();
				if(p!=0)
				printf(" %d ",p);
			}
				for(i=1;i<=n;i++)
				if(visit[i]==0)
				bfs(i,n);
}
//
int dfs(int s, int n)
{
	int i,k;
	push(s);
	visit[s]=1;
	k=pop();
	if(k!=0)
	printf("%d",k);
	while(k!=0)
	{
		for(i=1;i<=n;i++)
		if((a[k][i]!=0)&&(visit[i]==0))
		{
			push(i);
			visit[i]=1;
		}
		k=pop();
		if(k!=0)
		printf("%d",k);
	}
	for(i=1;i<=n;i++)
		if(visit[i]==0)
		dfs(i,n);
}
//
int main()
{
int n,i,s,ch,j;
char c,dummy;
printf("Enter the number of vertices in graph--> ");
scanf("%d",&n);
for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			printf("ENTER 1 IF %d HAS A NODE WITH %d ELSE 0--> ",i,j);
			scanf("%d",&a[i][j]);
		}
	}
printf("THE ADJACENCY MATRIX IS\n");
//
for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			printf(" %d",a[i][j]);
		}
		printf("\n");
	}
do
	{
		for(i=1;i<=n;i++)
		visit[i]=0;
		printf("\nMENU");
		printf("\n1.B.F.S");
		printf("\n2.D.F.S");
		printf("\nEnter ur choice");
		scanf("%d",&ch);
		printf("Enter source vertex :");
		scanf("%d",&s);
		switch(ch)
		{
			case 1: bfs(s,n);
			break;
			case 2: dfs(s,n);
			break;
		}
			printf("\nEnter 'y' to continue ? ");
			scanf("%c",&dummy);
			scanf("%c",&c);
	}
	while((c=='y')||(c=='Y'));
}
