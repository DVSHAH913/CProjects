/**DAA Individual Project
Implementation of Travelling Salesmen Problem
By Devshree Shah 
Batch S5
Rollno.:134
Enrollmentno.:21002170110026**/
//-----------------------------------------------------------------------------------------------------//
#include<stdio.h>
int Inmatgr[10][10],visited[10],n,cost=0;//global declaration of graph,dimensions and final cost.
//-----------------------------------------------------------------------------------------------------//
void quest() //Inputing the graph.
{
int i,j;
printf("Please state dimensions of graph : \n");
scanf("%d",&n);
printf("\nEnteries of Matrix\n");
for(i=0;i<n;i++)
{
printf("\nEnter Elements of Row: %d\n",i+1); //row-wise input
for( j=0;j<n;j++)
scanf("%d",&Inmatgr[i][j]);
visited[i]=0;
}
printf("\n\nThe cost list is:");
for( i=0;i<n;i++)
{
printf("\n");
for(j=0;j<n;j++)
printf("\t%d",Inmatgr[i][j]);
}
}
//-----------------------------------------------------------------------------------------------------// 
void TSP(int node) //minimum cost route
{
int i,next;
visited[node]=1;
printf("%d--->",node+1);
next=Track_next(node);
if(next==999) //Condition for minimum cost
{
next=0;
printf("%d",next+1);
cost+=Inmatgr[node][next];
return;
}
TSP(next); //recur TSP
}
//-----------------------------------------------------------------------------------------------------//
int Track_next(int c)//To find next node
{
int i,next=999;
int min=999,min1;
for(i=0;i<n;i++)
{
if((Inmatgr[c][i]!=0)&&(visited[i]==0)) 
if(Inmatgr[c][i]+Inmatgr[i][c]<min)
{
min=Inmatgr[i][0]+Inmatgr[c][i];
min1=Inmatgr[c][i];
next=i;
}
}
if(min!=999)
cost+=min1;
return next;
}
//-----------------------------------------------------------------------------------------------------//
int main()
{
quest();
printf("\n\nThe Path is:\n");
TSP(0); //passing 0 because starting vertex
printf("\n\nMinimum cost is %d\n ",cost);
return 0;
}

