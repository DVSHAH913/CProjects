#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct node
{
	char name[50];
	int carno;
	struct node *next;                   //this is triply linked list for company
	struct node *last;
	struct node *up;
	
}*head=NULL,*END=NULL;

struct node1
{
	struct node *next;
	struct node *last;
	struct node *down;
	char model[20];                         //this is triply linked list for cars of companies
	int price;
	char ctp[100];
}*head1[1000],*END1[1000];
int count=0;                                //here count is globally declared because we have to use count as a sr number for cars for a company

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//->function to add at first
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int addatfirst()
{
	int b,l,i,f;
	struct node *newnode;
	newnode=(struct node*)malloc(sizeof(struct node));
	
	fflush(stdin);
	printf("Enter CAR NAME to enter at first:");
	gets(newnode->name);
	newnode->carno=count;
//////////////////////Here 2nd link list starts/////////////////////////////////////
	
	printf("Enter how many models are available:");
	scanf("%d",&f);
	if(f>0)
	{
		struct node1 *newnode1;
		
		for(i=0;i<f;i++)
		{
			newnode1=(struct node*)malloc(sizeof(struct node));
			fflush(stdin);
			printf("Enter model:");
			gets(newnode1->model);
			printf("Enter price:");
			scanf("%d",&newnode1->price);
			fflush(stdin);
			printf("Enter CC,torque and power:");
			gets(newnode1->ctp);
			
			if(i==0)
			{
				head1[count]=END1[count]=NULL;
				newnode1->last=head1[count];
				newnode1->next=END1[count];
				newnode1->down=newnode;
				head1[count]=END1[count]=newnode1;
			}
			else
			{
				newnode1->last=END1[count];
				newnode1->next=NULL;
				newnode1->down=newnode;
				END1[count]->next=newnode1;
				END1[count]=newnode1;
			}
		}
		
		//////////////////////Here 2nd link list ends/////////////////////////////////////
		
		if(head==NULL)
		{
			newnode->next=newnode->last=NULL;
			head=END=newnode;
			newnode->up=head1[count];
		}
		else
		{
			newnode->last=NULL;
			newnode->next=head;
			head->last=newnode;
			head=newnode;
			newnode->up=head1[count];
		}
		count++;
	}
	else
	{
		printf("cannot input less than 1");
		getch();
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//->code for inserting at end
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int addatend()
{
	int i,l,f;
	
	struct node*newnode;
	newnode=(struct node*)malloc(sizeof(struct node));
	
	fflush(stdin);
	printf("Enter CAR NAME to enter at end :");
	gets(newnode->name);
	newnode->carno=count;
	
	//////////////////////Here 2nd link list starts/////////////////////////////////////
	
	printf("Enter how many models are available:");
	scanf("%d",&f);
	if(f>0)
	{
		struct node1 *newnode1;
		
		for(i=0;i<f;i++)
		{
			newnode1=(struct node*)malloc(sizeof(struct node));
			fflush(stdin);
			printf("Enter model:");
			gets(newnode1->model);
			printf("Enter price:");
			scanf("%d",&newnode1->price);
			fflush(stdin);
			printf("Enter CC,torque and power:");
			gets(newnode1->ctp);
			
			if(i==0)
			{
				head1[count]=END1[count]=NULL;
				//struct node1 *temp1=head1[count];
				
				newnode1->last=head1[count];
				newnode1->next=END1[count];
				newnode1->down=newnode;
				head1[count]=END1[count]=newnode1;
			}
			else
			{
				END1[count]->next=newnode;
				newnode1->last=END1[count];
				newnode1->next=NULL;
				newnode1->down=newnode;
				
				END1[count]=newnode1;
			}
		}
		
		//////////////////////Here 2nd link list ends/////////////////////////////////////
		
		
		if(head==NULL)
		{
			newnode->next=NULL;
			END=head=newnode;
			newnode->up=head1[count];
		}
		else
		{
			END->next=newnode;
			newnode->last=END;
			newnode->next=NULL;
			END=newnode;
			newnode->up=head1[count];
		}
		count++;
	}
	else
	{
		printf("cannot input less than 1");
		getch();
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//->function for display
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int display()
{
	int i=1,s=0;
	char n;
	struct node *temp=head;
	struct node1 *temp1;
	if(head==NULL)
	{
		printf("list is empty");
		getch();
	}
	else
	{
		while(1)
		{
			system("cls");
			printf("\n\n\t\t\t\t\t\tdata %d:",i);
			puts(temp->name);
			getch();
			printf("\n\n\n\n\n\nPress <- to see previous data,Press -> to see next data,Press up key to see models,Press esc to exit: ");
			getch();
			n=getch();
			if(n==77)
			{
				if(temp->next==NULL)
				{
					printf("\ncant move forward");
					getch();
				}
				else
				{
					i++;
					temp=temp->next;
				}
			}
			if(n==75)
			{
				if(temp->last==NULL)
				{
					printf("\ncant move backwards");
					getch();
				}
				else
				{
					i--;
					temp=temp->last;
				}
			}
			if(n==72)
			{
				temp1=head1[temp->carno];
					
				while(1)
				{
					system("cls");
					printf("\n\n");
					puts(temp->name);
					printf("\n\n\n\n\n,Press -> to see next model,Press <- to see previous model,Press ESC to go back\n\n\n\n\n\n");
					
					printf("\nModel name: ");
					puts(temp1->model);
					
					printf("\nPrice:%d ",temp1->price);
				
					printf("\nEngine cc, Torque and Horse power: ");
					puts(temp1->ctp);
					
					n=getch();
					if(n==77)
					{
						if(temp1->next==NULL)
						{
							printf("\ncant move forward");
							getch();
						}
						else
						{
							temp1=temp1->next;
						}
					}
					if(n==75)
					{
						if(temp1->last==NULL)
						{
							printf("\ncant move backwards");
							getch();
						}
						else
						{
							temp1=temp1->last;
						}
					}
					if(n==27)
						goto s;
				}
				s:
					n=28;
					s=1;
			}
			if(n==27)
				goto i;
		}
		i:
			i=1;
	}
} 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//->deletion code;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void deleteatnode()
{
	int n,i=1;
	struct node *temp=head;
	printf("Enter node position : ");
	scanf("%d",&n);
	if(n>0&&n<=count)
	{
		while(i!=n)
		{
			temp=temp->next;
			i++;
		}
		if(n==1)                                                             //this condition is if node asked to delete is first
		{
			if(head==NULL)
				printf("List empty");
			else
			{
				if(head->next==NULL)
				{
					free(head);
					head=END=NULL;
					printf("element deleted at first");
					getch();
				}
				else
				{
					head=temp->next;
					head->last=NULL;
					free(temp);
					printf("element deleted at first");
					getch();
				}
			}
		}
		else if(temp->next==NULL)                                              //this condition is if node asked to delete is last
		{
			if(head==NULL)
				printf("List empty");
			else
			{
				END=temp->last;
				END->next=NULL;
				printf("element delete at last(%d)",i);
				getch();
				free(temp);
			
			}
		}
		else                                                       //this condition is if node asked to delete is at any other position
		{
			temp->last->next=temp->next;
			temp->next->last=temp->last;
			printf("element delete at %d position",i);
			getch();
			free(temp);
		}
	}
	else
	{
		printf("wrong value inserted");
		getch();
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//->main driver code
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int main()
{
	int n=1;
	char pass[20];
	while(n!=0)
	{
		printf("1.Press 1 to insert at front\n2.Press 2 to insert at end\n3.Press 3 to delete at Any node\n4.Press 4 to display\n5.Press 5 to exit\n");
		scanf("%d",&n);
		if(n==1||n==2||n==3)
		{
			printf("Enter password : ");
			fflush(stdin);
			gets(pass);
			if(pass[0]=='S'&&pass[1]=='A'&&pass[2]=='C'&&pass[3]=='h'&&pass[4]=='i'&&pass[5]=='n'&&pass[6]=='\0')
				switch(n)
				{
					case 1:
						addatfirst();
						break;
					case 2:
						addatend();
						break;
					case 3:
						if(head==NULL)
						{
								printf("List empty");
								getch();
						}
						else
							deleteatnode();
						break;
				}
			else
			{
				printf("Wrong password");
				getch();
			}
				
		}
		else
			switch(n)
			{
				case 4:
					display();
					break;
				case 5:
					n=0;
					break;
				default:
					printf("invalid input");
					getch();
					break;
			}
			system("cls");
	}
	
}
